#!/sbin/sh
RIRU_PATH="/data/misc/riru"
rm -f "$RIRU_PATH/api_version"
rm -f "$RIRU_PATH/version_code"
rm -f "$RIRU_PATH/version_name"